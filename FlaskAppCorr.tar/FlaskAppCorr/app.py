from flask import Flask
from flask import request  # import fla
import requests
import time
import os

app = Flask(__name__)  # create an app instance
UPSTREAM_HOST=os.environ["UPSTREAM_HOST"]
UPSTREAM_PORT=os.environ["UPSTREAM_PORT"]


@app.route("/exitcall")
def do_pyappget():
    requests.get("http://"+UPSTREAM_HOST+":"+UPSTREAM_PORT+"/")
    return "Exit call"

@app.route("/exitcallnodejs")
def do_pyappget_nodejs():
    requests.get("http://"+UPSTREAM_HOST+":"+UPSTREAM_PORT+"/app")
    return "Exit call to Nodejs"

@app.route("/exitcalljava")
def do_pyappget_java():
    requests.get("http://"+UPSTREAM_HOST+":"+UPSTREAM_PORT+"/techstack/servlet.my1")
    return "Exit call to Java"

@app.route("/getter")
def do_pyapp():
    return " Getter Function flask App"

port = int(os.environ['APP_PORT'])
app.run(host='0.0.0.0', port=port)
