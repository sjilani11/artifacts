from flask import Flask
from flask import request,abort
import requests
import time
import os

app = Flask(__name__)  # create an app instance

@app.route("/")  # at the end point /
def do_get_hello():  # call method hello
    return "Hello!"

@app.route("/helloget")  # at the end point /
def do_get():  # call method hello
    return "Hello World GET!"

@app.route("/httpcall")  # at the end point /
def do_http_call():
    return "Hello Httpcall"

@app.route("/hellopost", methods=["POST"])
def do_post():
    return "Hello World POST"

@app.route("/slow")
def do_slow():
	time.sleep(.6)
	return "Hello World slow"

@app.route("/responsetime")
def responsetime():
	time.sleep(2)
	return "Responsetime 2 sec slow"

@app.route("/verySlow")
def do_very_slow():
	time.sleep(.8)
	return "Hello World very slow"

@app.route('/exit/http', methods = ['POST', 'GET', 'PUT', 'DELETE'])
def bye():
      result = requests.get('https://www.google.com').status_code
      return 'Hi Hello! %d' %result

@app.route("/error404") 
def error_404():  # call method error404
	abort(404)
	return "Error 404"

# @app.errorhandler(404)
# def err(e):
# 	raise Exception("Custom Exception")
# 	return 'Status CODE:500'

port = int(os.environ['APP_PORT'])
app.run(host='0.0.0.0', port=port)

    
