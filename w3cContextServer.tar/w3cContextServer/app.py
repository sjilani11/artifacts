import flask
from flask import Flask,request
import requests
from opentelemetry.instrumentation.flask import FlaskInstrumentor
import os
# from opentelemetry.instrumentation.wsgi import OpenTelemetryMiddleware
# UPSTREAM SERVER
from opentelemetry.context import get_current
from opentelemetry.baggage import set_baggage, get_all
from opentelemetry.propagate import inject, extract
from opentelemetry.baggage import get_baggage
import opentelemetry.instrumentation.wsgi as otel_wsgi


port = int(os.environ['APP_PORT'])
app = Flask(__name__)




app = flask.Flask(__name__)
FlaskInstrumentor().instrument_app(app)
# app.wsgi_app = OpenTelemetryMiddleware(app.wsgi_app)

@app.route("/")
def hello():
    return "Hello!"

@app.route('/downstream')
def hello_world():
    extracted_context = extract(request.environ, getter=otel_wsgi.wsgi_getter)
    resp = flask.Response(get_baggage('my_key', extracted_context))
    resp.headers['Custom-header-baggage'] = get_baggage('my_key', extracted_context)
    return resp

@app.route("/http")
def http():
    resp = flask.Response("Foo bar baz")
    resp.headers['Custom-header'] = '*,9,10,HelloMan'
    resp.headers['CUstom_header-1'] = 'custom header abc'
    print('http called!')
    print(request.headers)
    return resp

@app.route("/home")
def home():
    print('Called me!')
    headers = {'foobar': 'raboof'}
    requests.get('http://localhost:'+str(port)+'/http',headers=headers)
    return "hello"



if __name__ == "__main__":
    app.run(host='0.0.0.0', port=port)
